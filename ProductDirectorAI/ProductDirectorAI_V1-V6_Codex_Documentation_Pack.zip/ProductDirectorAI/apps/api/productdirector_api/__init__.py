"""ProductDirectorAI local API."""
